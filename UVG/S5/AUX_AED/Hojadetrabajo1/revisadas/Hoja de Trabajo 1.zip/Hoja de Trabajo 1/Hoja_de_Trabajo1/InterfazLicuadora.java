public interface InterfazLicuadora 
{
    void turnOn(); // Encender la licuadora
    void fill(String ingredient); // Llenar la licuadora
    void increaseSpeed(); // Incrementar
    void decreaseSpeed(); // Disminuir
    int getSpeed(); // velocidad actual
    boolean isFilled(); // si está llena
    void empty(); // Vaciar la licuadora
}
