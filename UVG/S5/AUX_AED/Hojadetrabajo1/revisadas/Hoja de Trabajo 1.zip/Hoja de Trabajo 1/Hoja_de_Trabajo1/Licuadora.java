public class Licuadora implements InterfazLicuadora 
{
    private boolean isOn;
    private boolean isFilled;
    private int speed;
    private String ingredient;

    public Licuadora() 
    {
        this.isOn = false;
        this.isFilled = false;
        this.speed = 0;
        this.ingredient = null;
    }

    @Override
    public void turnOn() 
    {
        if (!isOn) 
        {
            isOn = true;
            System.out.println("La licuadora está encendida.");
        } 
        else 
        {
            System.out.println("La licuadora ya está encendida.");
        }
    }

    @Override
    public void fill(String ingredient) 
    {
        if (!isFilled) 
        {
            this.isFilled = true;
            this.ingredient = ingredient;
            System.out.println("Licuadora llena con: " + ingredient);
        } 
        else 
        {
            System.out.println("La licuadora ya está llena.");
        }
    }

    @Override
    public void increaseSpeed() 
    {
        if (!isOn) 
        {
            System.out.println("Debe encender la licuadora primero.");
            return;
        }
        if (!isFilled) 
        {
            System.out.println("Debe llenar la licuadora antes de usarla.");
            return;
        }
        if (speed < 10) 
        {
            speed++;
            System.out.println("Velocidad incrementada a: " + speed);
        } else 
        {
            System.out.println("La licuadora ya está en la velocidad máxima.");
        }
    }

    @Override
    public void decreaseSpeed() 
    {
        if (speed > 0) 
        {
            speed--;
            System.out.println("Velocidad disminuida a: " + speed);
        } 
        else 
        {
            System.out.println("La licuadora ya está apagada.");
        }
    }

    @Override
    public int getSpeed() 
    {
        return speed;
    }

    @Override
    public boolean isFilled() 
    {
        return isFilled;
    }

    @Override
    public void empty() 
    {
        if (isFilled) 
        {
            isFilled = false;
            ingredient = null;
            System.out.println("La licuadora está vacía.");
        } 
        else 
        {
            System.out.println("La licuadora ya está vacía.");
        }
    }
}



