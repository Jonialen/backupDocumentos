import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import your.package.InterfazLicuadora;
import your.package.Licuadora;

public class LicuadoraTest {

    @Test
    public void testTurnOn() {
        InterfazLicuadora licuadora = new Licuadora();
        licuadora.turnOn();
        assertEquals(0, licuadora.getSpeed(), "La velocidad inicial debe ser 0 al encender.");
    }

    @Test
    public void testFillBlender() {
        InterfazLicuadora licuadora = new Licuadora();
        licuadora.fill("Frutas");
        assertTrue(licuadora.isFilled(), "La licuadora debe estar llena después de usar fill.");
    }

    @Test
    public void testIncreaseSpeed() {
        InterfazLicuadora licuadora = new Licuadora();
        licuadora.turnOn();
        licuadora.fill("Frutas");
        licuadora.increaseSpeed();
        assertEquals(1, licuadora.getSpeed(), "La velocidad debe ser 1 después de incrementarla.");
    }

    @Test
    public void testCannotOperateEmptyBlender() {
        InterfazLicuadora licuadora = new Licuadora();
        licuadora.turnOn();
        licuadora.increaseSpeed();
        assertEquals(0, licuadora.getSpeed(), "La velocidad no debe cambiar si la licuadora está vacía.");
    }

    @Test
    public void testEmptyBlender() {
        InterfazLicuadora licuadora = new Licuadora();
        licuadora.fill("Agua");
        licuadora.empty();
        assertFalse(licuadora.isFilled(), "La licuadora debe estar vacía después de vaciarla.");
    }
}

