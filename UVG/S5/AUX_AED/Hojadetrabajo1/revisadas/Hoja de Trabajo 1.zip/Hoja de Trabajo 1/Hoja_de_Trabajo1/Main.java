import java.util.Scanner;

public class Main 
{
    public static void main(String[] args) 
    {
        InterfazLicuadora licuadora = new Licuadora(); // Usa la interfaz y su implementación
        Scanner scanner = new Scanner(System.in);
        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\n--- Menú de Licuadora ---");
            System.out.println("1. Encender la licuadora");
            System.out.println("2. Llenar la licuadora");
            System.out.println("3. Incrementar velocidad");
            System.out.println("4. Consultar velocidad actual");
            System.out.println("5. Verificar si está llena");
            System.out.println("6. Vaciar la licuadora");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");

            // Leer la opción del usuario
            int opcion;
            try 
            {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) 
            {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                continue;
            }

            if (opcion == 1) 
            {
                licuadora.turnOn();
            } 
            else if (opcion == 2) 
            {
                System.out.print("¿Qué desea licuar? ");
                String ingrediente = scanner.nextLine();
                licuadora.fill(ingrediente);
            } 
            else if (opcion == 3) 
            {
                licuadora.increaseSpeed();
            } 
            else if (opcion == 4) 
            {
                System.out.println("Velocidad actual: " + licuadora.getSpeed());
            } 
            else if (opcion == 5) 
            {
                System.out.println("¿Está llena? " + (licuadora.isFilled() ? "Sí" : "No"));
            } 
            else if (opcion == 6) 
            {
                licuadora.empty();
            } 
            else if (opcion == 7) 
            {
                System.out.println("Saliendo del programa.");
                isRunning = false;
            } 
            else 
            {
                System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }

        scanner.close();
    }
}
