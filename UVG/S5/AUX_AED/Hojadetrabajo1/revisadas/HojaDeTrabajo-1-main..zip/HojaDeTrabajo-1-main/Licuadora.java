/**
 * La interfaz Licuadora define las operaciones básicas para manejar una licuadora.
 * Incluye métodos para encender, apagar, llenar, vaciar, y ajustar la velocidad,
 * además de verificar el estado de la licuadora.
 */
public interface Licuadora {

    /**
     * Enciende la licuadora.
     * 
     * @return true si la licuadora se encendió correctamente, false si ya estaba encendida o hubo un error.
     */
    boolean encenderLicuadora();

    /**
     * Apaga la licuadora.
     * 
     * @return true si la licuadora se apagó correctamente, false si ya estaba apagada o hubo un error.
     */
    boolean apagarLicuadora();

    /**
     * Llena la licuadora con contenido.
     * 
     * @return true si la licuadora se llenó correctamente, false si ya estaba llena o no se pudo llenar.
     */
    boolean llenarLicuadora();

    /**
     * Vacía el contenido de la licuadora.
     * 
     * @return true si la licuadora se vació correctamente, false si ya estaba vacía o no se pudo vaciar.
     */
    boolean vaciarLicuadora();

    /**
     * Incrementa la velocidad de la licuadora a un nivel especificado.
     * 
     * @param velocidad el nivel de velocidad a establecer (debe ser positivo).
     * @return true si la velocidad se ajustó correctamente, false si la velocidad no es válida o no se pudo cambiar.
     */
    boolean incrementarVelocidad(int velocidad);

    /**
     * Obtiene la velocidad actual de la licuadora.
     * 
     * @return la velocidad actual de la licuadora.
     */
    int obtenerVelocidadActual();

    /**
     * Verifica si la licuadora está llena.
     * 
     * @return true si la licuadora está llena, false si está vacía.
     */
    boolean estaLlena();
}