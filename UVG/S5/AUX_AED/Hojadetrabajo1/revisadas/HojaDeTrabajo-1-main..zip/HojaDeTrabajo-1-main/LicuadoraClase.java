/**
 * La clase LicuadoraClase implementa la interfaz Licuadora y define el comportamiento de una licuadora.
 * Esta clase incluye atributos para el estado de encendido, si está llena, y la velocidad actual.
 */
class LicuadoraClase implements Licuadora {

    /** Indica si la licuadora está encendida. */
    private boolean encendido;

    /** Indica si la licuadora está llena. */
    private boolean llena;

    /** Representa la velocidad actual de la licuadora. */
    private int velocidad;

    /**
     * Constructor de la clase LicuadoraClase.
     * Inicializa la licuadora apagada, vacía y con velocidad en 0.
     */
    public LicuadoraClase() {
        this.encendido = false;
        this.llena = false;
        this.velocidad = 0;
    }

    /**
     * Enciende la licuadora si está llena y actualmente apagada.
     * Al encender, establece la velocidad inicial en 1.
     *
     * @return true si la licuadora se encendió correctamente, false de lo contrario.
     */
    @Override
    public boolean encenderLicuadora() {
        if (!this.encendido && this.llena) {
            this.encendido = true;
            this.velocidad = 1;
            return true;
        }
        return false;
    }

    /**
     * Apaga la licuadora si está encendida.
     * Al apagar, la velocidad se reinicia a 0.
     *
     * @return true si la licuadora se apagó correctamente, false de lo contrario.
     */
    @Override
    public boolean apagarLicuadora() {
        if (this.encendido) {
            this.encendido = false;
            this.velocidad = 0;
            return true;
        }
        return false;
    }

    /**
     * Llena la licuadora si actualmente está vacía.
     *
     * @return true si la licuadora se llenó correctamente, false si ya estaba llena.
     */
    @Override
    public boolean llenarLicuadora() {
        if (this.llena) {
            return false;
        } else {
            this.llena = true;
        }
        return true;
    }

    /**
     * Vacía la licuadora si actualmente está llena.
     *
     * @return true si la licuadora se vació correctamente, false si ya estaba vacía.
     */
    @Override
    public boolean vaciarLicuadora() {
        if (!this.llena) {
            return false;
        } else {
            this.llena = false;
        }
        return true;
    }

    /**
     * Incrementa la velocidad de la licuadora en un valor especificado.
     * La velocidad se ajusta solo si la licuadora está encendida y el nuevo valor
     * está en el rango permitido (entre 1 y 12).
     *
     * @param velocidad el incremento de velocidad a aplicar.
     * @return true si la velocidad se ajustó correctamente, false de lo contrario.
     */
    @Override
    public boolean incrementarVelocidad(int velocidad) {
        if (this.encendido && this.velocidad + velocidad <= 12 && this.velocidad + velocidad >= 1) {
            this.velocidad = this.velocidad + velocidad;
            return true;
        }
        return false;
    }

    /**
     * Obtiene la velocidad actual de la licuadora.
     *
     * @return la velocidad actual de la licuadora.
     */
    @Override
    public int obtenerVelocidadActual() {
        return this.velocidad;
    }

    /**
     * Verifica si la licuadora está llena.
     *
     * @return true si la licuadora está llena, false de lo contrario.
     */
    @Override
    public boolean estaLlena() {
        return llena;
    }
}