import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LicuadoraClaseTest {

    private LicuadoraClase licuadora;

    @BeforeEach
    void setUp() {
        licuadora = new LicuadoraClase(); // Se inicializa antes de cada prueba.
    }

    @Test
    void testEncenderLicuadora() {
        // La licuadora debe estar llena para encenderse
        assertFalse(licuadora.encenderLicuadora()); // No se puede encender aún.
        
        licuadora.llenarLicuadora(); // Llenamos la licuadora
        assertTrue(licuadora.encenderLicuadora()); // Ahora debería encenderse.
        assertEquals(1, licuadora.obtenerVelocidadActual()); // Velocidad inicial debe ser 1.
    }

    @Test
    void testIncrementarVelocidad() {
        licuadora.llenarLicuadora();
        licuadora.encenderLicuadora();

        assertTrue(licuadora.incrementarVelocidad(3)); // Incrementa la velocidad en 3.
        assertEquals(4, licuadora.obtenerVelocidadActual()); // La velocidad debe ser 4.

        assertFalse(licuadora.incrementarVelocidad(10)); // No puede exceder el límite de 12.
        assertEquals(4, licuadora.obtenerVelocidadActual()); // La velocidad sigue siendo 4.
    }
}
