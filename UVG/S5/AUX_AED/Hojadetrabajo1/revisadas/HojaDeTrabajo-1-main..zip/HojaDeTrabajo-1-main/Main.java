/**
 * Clase principal que interactúa con la clase LicuadoraClase.
 * Permite al usuario simular el uso de una licuadora mediante un menú interactivo.
 * 
 * @author Grupo 1 - HDT 1
 * @version 1
 * Clase principal
 * fecha_creación = 17/01/2025
 * fecha_modificación = 21/01/2025
 */

 import java.util.Scanner;

class Main
{
      /**
     * Método principal que inicia la simulación de una licuadora interactiva.
     * Presenta un menú al usuario con opciones para llenar, encender, ajustar la velocidad, apagar
     * o vaciar la licuadora.
     *
     * @param args argumentos de la línea de comandos (no utilizados).
     */
    public static void main(String[] args)
    {
        LicuadoraClase licuadora = new LicuadoraClase();
        boolean flag = true;
        Scanner sc = new Scanner(System.in);

        while(flag)
        {
            System.out.println("¿Qué desea hacer?");
            System.out.println("1) Llenar licuadora");
            System.out.println("2) Encender licuadora");
            System.out.println("3) Aumentar la velocidad");
            System.out.println("4) Disminuir la velocidad");
            System.out.println("5) Ver velocidad");
            System.out.println("6) Apagar licuadora");
            System.out.println("7) Vaciar licadora");
            System.out.println("8) Salir");
            String menu = sc.nextLine();

            if (menu.equals("1"))
            {
                if (licuadora.obtenerVelocidadActual()>0)
                {
                    System.out.println("La licuadora está en funcionamiento, ya está llena.");
                }
                else if (licuadora.llenarLicuadora())
                {
                    System.out.println("Se ha llenado la licuadora.");
                }
                else
                {
                    
                    System.out.println("La licuadora ya está llena.");
                }
            }

            else if (menu.equals("2"))
            {
                if (licuadora.encenderLicuadora())
                {
                    System.out.println("Se ha encendido la licuadora.");
                }
                else if (!licuadora.estaLlena())
                {
                    System.out.println("La licuadora no puede operar vacía.");
                }
                else
                {
                    System.out.println("La licuadora ya está encendida.");
                }
            }

            else if (menu.equals("3"))
            {
                if (licuadora.incrementarVelocidad(1))
                {
                    System.out.println("Se ha incrementado la velocidad.");
                }
                else if (licuadora.obtenerVelocidadActual() == 0)
                {
                    System.out.println("La licuadora está apagada.");
                }
                else
                {
                    System.out.println("La licuadora ya está en velocidad máxima.");
                }
            }

            else if (menu.equals("4"))
            {
                if (licuadora.incrementarVelocidad(-1))
                {
                    System.out.println("Se ha disminuido la velocidad.");
                }
                else if (licuadora.obtenerVelocidadActual() == 0)
                {
                    System.out.println("La licuadora está apagada.");
                }
                else
                {
                    System.out.println("La licuadora ya está en velocidad mínima.");
                }
            }

            else if (menu.equals("5"))
            {
                if (licuadora.obtenerVelocidadActual() == 0)
                {
                    System.out.println("La licuadora está apagada.");
                }
                else
                {
                    System.out.println("La velocidad de la licuadora es: " + licuadora.obtenerVelocidadActual() + ".");
                }
            }

            else if (menu.equals("6"))
            {
                if (licuadora.apagarLicuadora())
                {
                    System.out.println("La licuadora se ha apagado.");
                }
                else
                {
                    System.out.println("La licuadora ya está apagada.");
                }
            }

            else if (menu.equals("7"))
            {
                if (licuadora.obtenerVelocidadActual() == 0)
                {
                    if (licuadora.vaciarLicuadora())
                    {
                        System.out.println("Se ha vaciado la licuadora.");
                    }
                    else
                    {
                        System.out.println("La licuadora ya está vacía.");
                    }
                }
                else
                {
                    System.out.println("No se puede vaciar si la licuadora está encendida.");
                }
            }

            else if (menu.equals("8"))
            {
                flag = false;
            }
            
            else
            {
                System.out.println("No ingresó una opción correcta.");
            }
        }
    }
}